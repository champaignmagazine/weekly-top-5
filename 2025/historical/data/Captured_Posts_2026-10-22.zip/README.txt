AI by AI Weekly Top 5, 2025: captured posts
Source: WordPress export of champaignmagazine.com, generated 2026-10-22 06:21 UTC (collection date).
html/<post_id>.html  original post content (post_content as stored in WordPress, block markup included)
text/<post_id>.md    readable version, with title, IDs, dates and source URL in the header
Post IDs match the Register sheet in top5_2025_register.xlsx.
Revision history is not included: WordPress exports omit revisions.
